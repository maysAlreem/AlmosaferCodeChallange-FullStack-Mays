class ListingPage {

    CheapestFiltter = "div.sc-erOsFi.kaKlVJ > div > button.tab-btn.btn-glow.btn-glow--active.sc-eerKOB.bWTreD.sc-VigVT.jHPtub.btn.btn-default";
    SearchBar = "div.sc-fwNAQS.eCFxik.sc-cmthru.bfnznt";
    ContinueSelection = "div.sc-eKQksS.hjQmvt > div > button";
    ExpandPriceFiltterButton = "div:nth-child(5) > div.sc-ijhsb.hGCDkG > div > div";
    PriceFiltter = "div:nth-child(5) > div.sc-gKLXLV.gPMTSG > div";
    PriceFiltterMinValue = "div > div.sc-hTQSVH.iBpTbZ > span:nth-child(1)";

    VerifiyIfCheapestFiltterisSelected() {

        cy.get(this.CheapestFiltter).invoke('attr', 'data-testid').should('include', 'selected');

    }
    VerifiyIfSearchingIsDone() {
        cy.get(this.SearchBar).should('not.exist');
    }
    SelectTheFlightByListIndex(FlightIndex) {
        cy.get("a[data-testid='Group" + FlightIndex + "__FlightDetailsButton']").click();
    }
    checkIfContinueButtonIsExixt() {

        cy.get(this.ContinueSelection).should('exist');
    }
    SelectAndContinueBooking() {
        cy.get(this.ContinueSelection).click();
    }
    ExpandPriceFiltter() {
        cy.get(this.ExpandPriceFiltterButton).click();
    }
    VerifiyIfExpandFiltterBarIsVisibale() {
        cy.get(this.PriceFiltter).should("be.visible");
    }
    VerifiyIftwoTextItemIsEquel(TexrElement1, TextElement2) {
        let Text1;
        cy.get(TexrElement1).should((v1) => {
            Text1 = v1.text();
        });
        cy.get(TextElement2).should((v2) => {
            const text2 = v2.text();
            expect(Text1).to.contain(text2);
        });
    }
}
export default ListingPage