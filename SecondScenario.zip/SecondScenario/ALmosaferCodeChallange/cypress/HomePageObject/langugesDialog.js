class langugesDialog {
    USDLangugeButton = "button.sc-jTzLTM.hQpNle.cta__button.cta__continue.btn.btn-primary";


    clickOnUSDLangugeButton() {
        cy.get(this.USDLangugeButton).click();

    }


}
export default langugesDialog