class HomePageLinks {
    baseURL = "https://global.almosafer.com/";

    getBaseLink() {
        return this.baseURL
    }
    openAlmosaferWebsite() {
        cy.visit(this.baseURL);
    }


}
export default HomePageLinks