
class SearchFlights {
   Origin = "div.sc-gAmQfK.fYtftN > div > div > div > input";

   Destination = "div.sc-hAXbOi.llOopA > div.sc-bxivhb.uptWR.AutoComplete__Wrapper > div > div > input";

   DepartureDate = "div.sc-OxbzP.sc-lnrBVv.gKbptE  span.sc-fvLVrH.hNjEjT";

   ReturnDate = "div.sc-OxbzP.sc-bYnzgO.bojUIa > span.sc-fvLVrH.hNjEjT";

   //PassengerVaribles
   Passengers = "div.sc-fgrSAo.jItitG > div > div > div";
   totalNumOfPassengers = "div > div > div.sc-jHXLhC.gMJgar > span";
   PassengerAdultPlus12YearsCount = "div:nth-child(1) > div.sc-gjAXCV.jufPTc  div.sc-cSYcjD.htNoBo";
   //End PassengerVaribles

   //CabinClass Varibles
   CabinClass = "div.sc-cNnxps.cZRdNm > div > div";
   CabinClassSelectedValue = "div.sc-cNnxps.cZRdNm > div > div > span";
   CabinClassListValue = "div.sc-cNnxps.cZRdNm > div > div.sc-hCbubC.bAmbSV";
   //End CabinClass Varibles

   SearchButton = "div.sc-dxgOiQ.hTjMfW.sc-doWzTn.dRRVeE.col-lg-4.col-md-3 > div > button";


   //Orgin Feature 
   setOriginRandomly(testArray) {
      var OrginArray = testArray;
      var randomOrgin = OrginArray[Math.floor(Math.random() * (OrginArray.length))]
      cy.get(this.Origin).type(randomOrgin);
   }
   clickOnOriginItembyIndex(testedIndex) {
      cy.get("div > ul > li[data-testid='FlightSearchBox__AirportOption" + testedIndex + "']").click();
   }
   //End Orgin Feature

   //Destination Feature 
   setDestinationRandomly(testArray) {
      var DestinationArray = testArray;//["AMM", "CAI", "DEL", "KHI", "PAR"];
      var randomDestination = DestinationArray[Math.floor(Math.random() * (DestinationArray.length))]
      cy.get(this.Destination).type(randomDestination);
   }
   clickOnDestenationItembyIndex(testedIndex) {
      cy.get("div > ul > li[data-testid='FlightSearchBox__AirportOption" + testedIndex + "']").click();
   }
   setDestination() {
      cy.get(this.Destination);
   }
   //End Destination Feature

   //Start Departure Date Features
   setDepartureDate(DepartureDate) {
      cy.get(this.DepartureDate);
   }

   //End Departure Date Features
   setReturnDate(ReturnDate) {
      cy.get(this.ReturnDate);
   }
   GenerateRandomDateInFuture(FromDate, ToDate) {
      //  FromDate =new Date().getDate();

      return new Date(
         FromDate.getDate() +
         Math.random() * (ToDate.getDate() - FromDate.getDate()),
      );
   }
   //Passengers Features
   clickToSetPassengers() {
      cy.get(this.Passengers).click();
   }

   verifiyPassengerAdultPlus12YearsCount(numberOfneededPassenger) {
      cy.get(this.PassengerAdultPlus12YearsCount).contains(numberOfneededPassenger);
   }
   VerifiyTheTotalNumberOFPassengers(numberOfTotalPassengers) {
      cy.get(this.totalNumOfPassengers).contains(numberOfTotalPassengers);
   }

   //End Passengers Features

   //Cabin class Features
   clickTosetCabinClass() {
      cy.get(this.CabinClass).click();
   }

   VerifiyIfTheNeededValueIsExist(TestValue) {
      cy.get(this.CabinClassListValue).contains(TestValue);

   }
   ClickOnNeedeCabinClassValue(TestValueindex) {
      cy.get("div > div.sc-hCbubC.bAmbSV > div:nth-child(" + TestValueindex + ")").click();

   }
   //End Cabin class Features
   clickOnSearchFlight() {
      cy.get(this.SearchButton).click();
   }
}
export default SearchFlights