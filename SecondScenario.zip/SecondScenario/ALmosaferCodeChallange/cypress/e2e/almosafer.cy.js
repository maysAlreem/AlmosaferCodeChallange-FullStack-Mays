import HomePageLinks from "../HomePageObject/HomePageLinks"
import langugesDialog from "../HomePageObject/langugesDialog"
import SearchFlights from "../HomePageObject/SearchFlightsPage";
import ListingPage from "../FlightListingPageObject/ListingPage";


const homePageLinksObject = new HomePageLinks();
const langugesDialogObject = new langugesDialog();
const SearchFlightsObject = new SearchFlights();
const ListingPageObject = new ListingPage();
describe('Second Sceniario - QA_Full-Stack', () => {

  it('Open Almosafer.com URL (Select Flight) ', () => {
    //Navigate the base URL
    homePageLinksObject.openAlmosaferWebsite();
    //Check the en languge
    cy.url().should('include', 'global.almosafer.com/en');
    //Proceed with USD languge
    langugesDialogObject.clickOnUSDLangugeButton();
    //Fill The Orgin Randomly
    SearchFlightsObject.setOriginRandomly(["DXB", "AUH", "SHJ", "JED", "RUH"]);
    SearchFlightsObject.clickOnOriginItembyIndex(1);
    //Fill The Destination Randomly
    SearchFlightsObject.setDestinationRandomly(["AMM", "CAI", "DEL", "KHI", "PAR"]);
    SearchFlightsObject.clickOnDestenationItembyIndex(1);

    //Fill DeprtureDate in Future randomly
    //SearchFlightsObject.GenerateRandomDateInFuture(new Date(Date.now),new Date()); 
    
    //FillReturnDate in Future Randomly
    //SearchFlightsObject.GenerateRandomDateInFuture(new Date(Date.now),new Date()); 
    //Fill the Passengers with 1 Adult Value
    SearchFlightsObject.clickToSetPassengers();
    // Verifiy if the booked passengers is 1 Adult
    SearchFlightsObject.verifiyPassengerAdultPlus12YearsCount('1');
    SearchFlightsObject.VerifiyTheTotalNumberOFPassengers('1 Passenger');
    
    //FillTheCabinClass
    SearchFlightsObject.clickTosetCabinClass();
    //Verifiy if neede value is exist
    SearchFlightsObject.VerifiyIfTheNeededValueIsExist("Economy");
    //Choose the value (Economy)by index (reusable code)
    SearchFlightsObject.ClickOnNeedeCabinClassValue(1);

    //Click on search Button
    SearchFlightsObject.clickOnSearchFlight();
    cy.wait(16000);

    ListingPageObject.VerifiyIfCheapestFiltterisSelected();
    ListingPageObject.ExpandPriceFiltter();
    ListingPageObject.VerifiyIfExpandFiltterBarIsVisibale();

    ListingPageObject.VerifiyIftwoTextItemIsEquel(ListingPageObject.PriceFiltterMinValue, "div[data-testid='Group0__PriceLabel']");
    
    ListingPageObject.SelectTheFlightByListIndex(0);
    cy.wait(5000);
    ListingPageObject.checkIfContinueButtonIsExixt();
    ListingPageObject.SelectAndContinueBooking();


  })

})